package com.example.elgatonegro.utils

class Constants {
    companion object{
        val KEY_BOOK = "key_book"
    }
}