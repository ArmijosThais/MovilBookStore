package com.example.elgatonegro

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class ConfirmacionCompraActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_confirmacion_compra)
    }
}